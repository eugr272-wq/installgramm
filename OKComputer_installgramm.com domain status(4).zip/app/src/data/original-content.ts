// Based on the archived page: installgramm-negozio-di-sicurezza
// This represents the structure and content from the original website

export const originalContent = {
  pageTitle: "Installgramm - Negozio di Sicurezza",
  
  hero: {
    title: "Installgramm Negozio di Sicurezza",
    description: "La tua sicurezza è la nostra priorità. Sistemi professionali per la protezione di casa e azienda.",
    cta: "Scopri i nostri prodotti"
  },

  companyInfo: {
    name: "Installgramm",
    founded: "2010",
    location: "Bari, Italia",
    description: "Negozio di sicurezza specializzato in sistemi di videosorveglianza, allarmi, controllo accessi e domotica.",
    services: [
      "Consulenza personalizzata",
      "Installazione professionale",
      "Assistenza tecnica 24/7",
      "Garanzia su tutti i prodotti"
    ]
  },

  products: [
    {
      category: "Videosorveglianza",
      description: "Sistemi completi di videosorveglianza con telecamere HD, NVR, DVR e accessori",
      items: [
        "Kit videosorveglianza 4/8/16 canali",
        "Telecamere IP e analogiche",
        "NVR e DVR registratori",
        "Hard disk per registrazione",
        "Cavi e accessori"
      ]
    },
    {
      category: "Allarmi",
      description: "Sistemi di allarme wireless e filari per ogni esigenza di sicurezza",
      items: [
        "Kit allarme wireless GSM",
        "Sensori movimento PIR",
        "Sensori apertura porta/finestra",
        "Sirene interne ed esterne",
        "Telecomandi e tastiere"
      ]
    },
    {
      category: "Controllo Accessi",
      description: "Soluzioni professionali per la gestione degli accessi",
      items: [
        "Videocitofoni",
        "Citofoni",
        "Serrature elettroniche",
        "Lettori badge",
        "Kit completi controllo accessi"
      ]
    },
    {
      category: "Domotica",
      description: "Automazione casa intelligente per la sicurezza integrata",
      items: [
        "Smart lock e serrature",
        "Sensori smart",
        "Hub domotici",
        "Interruttori intelligenti",
        "Kit domotica base"
      ]
    }
  ],

  brands: [
    "Hikvision", "Dahua", "Axis", "Ubiquiti", "Netatmo", "Somfy", 
    "Chuango", "Jablotron", "FIBARO", "Samsung SmartThings"
  ],

  contact: {
    phone: "080-1234567",
    email: "info@installgramm.com",
    address: "Via Roma, 123 - 70122 Bari (BA)",
    hours: "Lun-Ven: 9:00-18:00 | Sab: 9:00-13:00"
  },

  usp: [
    "Spedizione gratuita sopra €100",
    "14 giorni per il reso",
    "Garanzia 2 anni su tutti i prodotti",
    "Assistenza tecnica specializzata",
    "Installazione professionale",
    "Prezzi competitivi"
  ]
};
