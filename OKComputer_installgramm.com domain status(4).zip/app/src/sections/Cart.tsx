import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/useCart';
import {
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { useNavigate } from 'react-router-dom';

export default function Cart() {
  const navigate = useNavigate();
  const {
    items,
    removeFromCart,
    updateQuantity,
    clearCart,
    totalItems,
    totalPrice,
  } = useCart();

  const handleCheckout = () => {
    navigate('/checkout');
  };

  return (
    <div className="flex flex-col h-full">
      <SheetHeader className="border-b pb-4">
        <SheetTitle className="flex items-center gap-2">
          <ShoppingBag className="w-5 h-5" />
          Il Tuo Carrello ({totalItems})
        </SheetTitle>
      </SheetHeader>

      {items.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <ShoppingBag className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Il carrello è vuoto
          </h3>
          <p className="text-gray-500 mb-6">
            Aggiungi alcuni prodotti per iniziare
          </p>
          <Button
            onClick={() => navigate('/#products')}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Continua lo Shopping
          </Button>
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto py-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex gap-4 p-4 border-b last:border-0"
              >
                {/* Product image */}
                <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Product info */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-gray-900 truncate mb-1">
                    {item.name}
                  </h4>
                  <p className="text-blue-600 font-semibold">
                    € {item.price.toFixed(2)}
                  </p>

                  {/* Quantity controls */}
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center border border-gray-200 rounded-lg">
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.quantity - 1)
                        }
                        className="p-2 hover:bg-gray-100 transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="px-3 text-sm font-medium">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.quantity + 1)
                        }
                        className="p-2 hover:bg-gray-100 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Item total */}
                <div className="text-right">
                  <p className="font-semibold text-gray-900">
                    € {(item.price * item.quantity).toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Cart footer */}
          <div className="border-t p-6 space-y-4">
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>Subtotale</span>
              <span>€ {totalPrice.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>Spedizione</span>
              <span className={totalPrice >= 100 ? 'text-green-600' : ''}>
                {totalPrice >= 100 ? 'Gratuita' : '€ 9.90'}
              </span>
            </div>
            <div className="flex items-center justify-between text-lg font-semibold">
              <span>Totale</span>
              <span className="text-blue-600">
                € {(totalPrice >= 100 ? totalPrice : totalPrice + 9.9).toFixed(2)}
              </span>
            </div>

            <Button
              onClick={handleCheckout}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg"
            >
              Procedi al Checkout
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>

            <Button
              variant="ghost"
              className="w-full text-gray-600"
              onClick={clearCart}
            >
              Svuota Carrello
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
