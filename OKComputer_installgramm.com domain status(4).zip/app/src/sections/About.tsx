import { Shield, Users, Award, Clock, CheckCircle } from 'lucide-react';

const stats = [
  { icon: Users, value: '50.000+', label: 'Clienti Soddisfatti' },
  { icon: Award, value: '11+', label: 'Anni di Esperienza' },
  { icon: Shield, value: '200+', label: 'Prodotti in Catalogo' },
  { icon: Clock, value: '24/7', label: 'Assistenza Tecnica' },
];

const usp = [
  { icon: CheckCircle, text: "Spedizione gratuita sopra €100" },
  { icon: CheckCircle, text: "14 giorni per il reso" },
  { icon: CheckCircle, text: "Garanzia 2 anni su tutti i prodotti" },
  { icon: CheckCircle, text: "Assistenza tecnica specializzata" },
  { icon: CheckCircle, text: "Installazione professionale" },
  { icon: CheckCircle, text: "Prezzi competitivi" },
];

export default function About() {
  return (
    <section id="about" className="w-full py-16 lg:py-24 bg-gray-50">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1557324232-b891f2dff4de?w=800&h=600&fit=crop"
                alt="Installgramm Security Systems"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-600/10 rounded-full -z-10" />
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-blue-600/10 rounded-full -z-10" />
          </div>

          {/* Content */}
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Installgramm - La Nostra Storia
            </h2>
            <div className="space-y-4 text-gray-600">
              <p>
                <span className="font-semibold text-gray-900">Installgramm</span> è nata nel 2013 a Sansepolcro (AR) con una missione chiara: rendere la sicurezza professionale accessibile a tutti. 
                Da oltre 11 anni siamo leader nel settore dei sistemi di sicurezza per la casa e le aziende in tutta Italia.
              </p>
              <p>
                Offriamo una vasta gamma di prodotti delle migliori marche, dai sistemi di 
                videosorveglianza agli allarmi wireless, dal controllo accessi alla domotica. 
                La nostra esperienza ci permette di consigliare sempre la soluzione migliore 
                per le esigenze di ogni cliente.
              </p>
              <p>
                Siamo orgogliosi di offrire non solo prodotti di alta qualità, ma anche un 
                servizio clienti eccezionale. Il nostro team di esperti è sempre disponibile 
                per assistenza tecnica e consulenza personalizzata.
              </p>
            </div>

            {/* USP List */}
            <div className="grid sm:grid-cols-2 gap-3 mt-8">
              {usp.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <item.icon className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{item.text}</span>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-10 pt-10 border-t border-gray-200">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-blue-600/10 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <stat.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
