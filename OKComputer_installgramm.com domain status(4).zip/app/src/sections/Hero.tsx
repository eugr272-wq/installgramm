import { ArrowRight, Shield, Truck, Headphones, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

export default function Hero() {
  const navigate = useNavigate();

  return (
    <section id="home" className="relative w-full overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1557324232-b891f2dff4de?w=1920&h=1080&fit=crop"
          alt="Security background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/90 via-gray-900/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative w-full px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600/20 backdrop-blur-sm rounded-full mb-6">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-medium text-blue-300">
              Installgramm - Negozio di Sicurezza dal 2013
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
            Installgramm
            <span className="block text-blue-400">Negozio di Sicurezza</span>
          </h1>

          <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-2xl">
            La tua sicurezza è la nostra priorità. Sistemi professionali per la protezione di casa e azienda. 
            Specializzati in videosorveglianza, allarmi, controllo accessi e domotica. A Sansepolcro dal 2013.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
              onClick={() => navigate('/catalog/videosorveglianza')}
            >
              Scopri i nostri prodotti
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg"
            >
              Richiedi Consulenza
            </Button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                <Truck className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-semibold">Spedizione Gratuita</p>
                <p className="text-gray-400 text-sm">Sopra €100</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                <Headphones className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-semibold">Assistenza 24/7</p>
                <p className="text-gray-400 text-sm">Sempre con te</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                <Award className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-semibold">Garanzia 2 Anni</p>
                <p className="text-gray-400 text-sm">Su tutti i prodotti</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
