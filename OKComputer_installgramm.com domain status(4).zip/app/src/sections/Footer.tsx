import { Shield, Facebook, Instagram, Twitter, Youtube, CreditCard, Truck, ShieldCheck } from 'lucide-react';

const footerLinks = {
  prodotti: [
    { name: 'Videosorveglianza', href: '#products' },
    { name: 'Allarmi', href: '#products' },
    { name: 'Controllo Accessi', href: '#products' },
    { name: 'Domotica', href: '#products' },
    { name: 'Novità', href: '#products' },
    { name: 'Offerte', href: '#products' },
  ],
  assistenza: [
    { name: 'Centro Assistenza', href: '#contact' },
    { name: 'Installazione', href: '#contact' },
    { name: 'Garanzie', href: '#contact' },
    { name: 'Resi e Rimborsi', href: '#contact' },
    { name: 'FAQ', href: '#contact' },
  ],
  azienda: [
    { name: 'Chi Siamo', href: '#about' },
    { name: 'Contatti', href: '#contact' },
    { name: 'Lavora con Noi', href: '#contact' },
    { name: 'Diventa Partner', href: '#contact' },
    { name: 'Blog', href: '#home' },
  ],
  legal: [
    { name: 'Privacy Policy', href: '#' },
    { name: 'Cookie Policy', href: '#' },
    { name: 'Termini e Condizioni', href: '#' },
  ],
};

const paymentMethods = [
  'Visa', 'Mastercard', 'PayPal', 'Apple Pay', 'Google Pay'
];

export default function Footer() {
  return (
    <footer className="w-full bg-gray-900 text-white">
      {/* Newsletter */}
      <div className="w-full px-4 sm:px-6 lg:px-8 py-12 border-b border-gray-800">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-4">
            Iscriviti alla Newsletter
          </h3>
          <p className="text-gray-400 mb-6">
            Ricevi offerte esclusive e aggiornamenti sui nostri prodotti
          </p>
          <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Inserisci la tua email"
              className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
              Iscriviti
            </button>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="w-full px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <a href="#home" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">Installgramm</span>
            </a>
            <p className="text-gray-400 text-sm mb-4">
              Sistemi di sicurezza professionali per la tua casa e il tuo business. 
              Dal 2010 al tuo fianco.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-semibold mb-4">Prodotti</h4>
            <ul className="space-y-2">
              {footerLinks.prodotti.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4">Assistenza</h4>
            <ul className="space-y-2">
              {footerLinks.assistenza.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold mb-4">Azienda</h4>
            <ul className="space-y-2">
              {footerLinks.azienda.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6 border-t border-gray-800">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
            {footerLinks.legal.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="hover:text-white transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>
          <p className="text-sm text-gray-400">
            © 2024 Installgramm. Tutti i diritti riservati.
          </p>
        </div>
      </div>

      {/* Payment & Shipping */}
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6 border-t border-gray-800 bg-gray-800/50">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4 text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span>Metodi di pagamento sicuri</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4" />
              <span>Spedizione gratuita sopra €100</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              <span>Garanzia 2 anni</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">Pagamenti accettati:</span>
            <div className="flex gap-1">
              {paymentMethods.map((method) => (
                <span
                  key={method}
                  className="px-2 py-1 bg-gray-700 rounded text-xs text-gray-300"
                >
                  {method}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
