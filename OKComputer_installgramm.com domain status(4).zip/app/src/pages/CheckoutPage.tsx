import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck, Shield, ChevronLeft, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/hooks/useCart';

// PayPal SDK Loader
const loadPayPalScript = () => {
  return new Promise<void>((resolve, reject) => {
    if (window.paypal) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://www.paypal.com/sdk/js?currency=EUR&client-id=sb';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load PayPal script'));
    document.head.appendChild(script);
  });
};

declare global {
  interface Window {
    paypal: any;
  }
}

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('paypal');
  const [paypalLoaded, setPaypalLoaded] = useState(false);
  const [paypalError, setPaypalError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    province: '',
    zipCode: '',
    phone: '',
    notes: '',
  });
  const [shippingMethod, setShippingMethod] = useState('standard');

  const shippingCost = totalPrice >= 100 ? 0 : shippingMethod === 'express' ? 15 : 9.90;
  const totalWithShipping = totalPrice + shippingCost;

  useEffect(() => {
    if (items.length === 0) {
      navigate('/');
      return;
    }

    loadPayPalScript()
      .then(() => setPaypalLoaded(true))
      .catch(() => {
        setPaypalLoaded(true);
        setPaypalError('PayPal non disponibile. Usa il pagamento con carta.');
      });
  }, [items.length, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePayPalPayment = () => {
    if (!window.paypal) {
      alert('PayPal non disponibile al momento');
      return;
    }

    window.paypal.Buttons({
      createOrder: (_data: any, actions: any) => {
        return actions.order.create({
          purchase_units: [{
            amount: {
              value: totalWithShipping.toFixed(2),
              currency_code: 'EUR'
            },
            description: `Ordine Installgramm - ${items.length} prodotti`,
          }]
        });
      },
      onApprove: (_data: any, actions: any) => {
        return actions.order.capture().then((details: any) => {
          console.log('PayPal Payment Success:', details);
          clearCart();
          navigate('/confirmation', { state: { orderId: details.id, paymentMethod: 'paypal' } });
        });
      },
      onError: (err: any) => {
        console.error('PayPal Error:', err);
        alert('Errore nel pagamento PayPal. Riprova.');
      }
    }).render('#paypal-button-container');
  };

  useEffect(() => {
    if (paypalLoaded && paymentMethod === 'paypal' && step === 3) {
      handlePayPalPayment();
    }
  }, [paypalLoaded, paymentMethod, step]);

  const handleCardPayment = () => {
    // Simulate card payment
    const orderId = 'ORD-' + Date.now();
    clearCart();
    navigate('/confirmation', { state: { orderId, paymentMethod: 'card' } });
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentMethod === 'card') {
      handleCardPayment();
    }
  };

  return (
    <div className="w-full py-8 lg:py-12">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Checkout</h1>
          <Button
            variant="outline"
            onClick={() => navigate('/')}
            className="flex items-center gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Continua lo Shopping
          </Button>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-12">
          <div className="flex items-center gap-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= s
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-24 h-1 mx-4 ${
                      step > s ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Form Steps */}
          <div className="lg:col-span-2">
            {/* Step 1: Contact & Shipping */}
            {step === 1 && (
              <form onSubmit={(e) => { e.preventDefault(); setStep(2); }}>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Informazioni di Contatto
                  </h2>
                  <div className="grid sm:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Nome *</label>
                      <Input name="firstName" value={formData.firstName} onChange={handleInputChange} required placeholder="Mario" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Cognome *</label>
                      <Input name="lastName" value={formData.lastName} onChange={handleInputChange} required placeholder="Rossi" />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                      <Input type="email" name="email" value={formData.email} onChange={handleInputChange} required placeholder="mario@email.com" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Telefono *</label>
                      <Input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} required placeholder="+39 333 1234567" />
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Indirizzo di Spedizione
                  </h2>
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Indirizzo *</label>
                    <Input name="address" value={formData.address} onChange={handleInputChange} required placeholder="Via Roma, 123" />
                  </div>
                  <div className="grid sm:grid-cols-3 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Città *</label>
                      <Input name="city" value={formData.city} onChange={handleInputChange} required placeholder="Sansepolcro" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Provincia *</label>
                      <Input name="province" value={formData.province} onChange={handleInputChange} required placeholder="AR" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">CAP *</label>
                      <Input name="zipCode" value={formData.zipCode} onChange={handleInputChange} required placeholder="52037" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Note per il corriere</label>
                    <textarea name="notes" value={formData.notes} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" rows={3} placeholder="Lascia il pacco con il vicino..." />
                  </div>
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg">
                  Continua con la Spedizione
                </Button>
              </form>
            )}

            {/* Step 2: Shipping Method */}
            {step === 2 && (
              <form onSubmit={(e) => { e.preventDefault(); setStep(3); }}>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Metodo di Spedizione
                  </h2>
                  <div className="space-y-4">
                    <label className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${shippingMethod === 'standard' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <div className="flex items-center gap-4">
                        <input type="radio" name="shipping" value="standard" checked={shippingMethod === 'standard'} onChange={(e) => setShippingMethod(e.target.value)} className="w-4 h-4 text-blue-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Spedizione Standard</p>
                          <p className="text-sm text-gray-600">Consegna in 5-7 giorni lavorativi</p>
                        </div>
                      </div>
                      <span className="font-semibold text-gray-900">
                        {totalPrice >= 100 ? 'Gratis' : '€ 9.90'}
                      </span>
                    </label>
                    <label className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${shippingMethod === 'express' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <div className="flex items-center gap-4">
                        <input type="radio" name="shipping" value="express" checked={shippingMethod === 'express'} onChange={(e) => setShippingMethod(e.target.value)} className="w-4 h-4 text-blue-600" />
                        <div>
                          <p className="font-semibold text-gray-900">Spedizione Express</p>
                          <p className="text-sm text-gray-600">Consegna in 1-2 giorni lavorativi</p>
                        </div>
                      </div>
                      <span className="font-semibold text-gray-900">€ 15.00</span>
                    </label>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Indietro
                  </Button>
                  <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg">
                    Continua con il Pagamento
                  </Button>
                </div>
              </form>
            )}

            {/* Step 3: Payment */}
            {step === 3 && (
              <form onSubmit={handleSubmitOrder}>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Metodo di Pagamento
                  </h2>
                  
                  {paypalError && (
                    <div className="flex items-center gap-2 p-4 bg-yellow-50 border border-yellow-200 rounded-lg mb-6">
                      <AlertCircle className="w-5 h-5 text-yellow-600" />
                      <span className="text-sm text-yellow-800">{paypalError}</span>
                    </div>
                  )}

                  <div className="space-y-4 mb-6">
                    <label className={`flex items-center gap-4 p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'paypal' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <input type="radio" name="payment" value="paypal" checked={paymentMethod === 'paypal'} onChange={(e) => setPaymentMethod(e.target.value)} className="w-4 h-4 text-blue-600" />
                      <div className="flex items-center gap-2">
                        <svg className="w-8 h-8 text-blue-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a3.35 3.35 0 0 0-.607-.541c-.013.076-.026.175-.041.254-.617 3.416-3.074 4.606-6.047 4.606h-2.19c-.524 0-.968.383-1.05.9l-1.12 7.106H7.076l2.47-15.436h5.424c1.893 0 3.404.473 4.15 1.686.435.747.51 1.616.346 2.647z"/>
                        </svg>
                        <span className="font-semibold">PayPal</span>
                      </div>
                    </label>
                    <label className={`flex items-center gap-4 p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'card' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <input type="radio" name="payment" value="card" checked={paymentMethod === 'card'} onChange={(e) => setPaymentMethod(e.target.value)} className="w-4 h-4 text-blue-600" />
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-6 h-6 text-gray-600" />
                        <span className="font-semibold">Carta di Credito</span>
                      </div>
                    </label>
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="space-y-4 mt-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Numero Carta *</label>
                        <Input placeholder="1234 5678 9012 3456" required />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Scadenza *</label>
                          <Input placeholder="MM/AA" required />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">CVV *</label>
                          <Input placeholder="123" required />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Titolare Carta *</label>
                        <Input placeholder="Mario Rossi" required />
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'paypal' && (
                    <div id="paypal-button-container" className="mt-6"></div>
                  )}
                </div>

                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={() => setStep(2)} className="flex-1">
                    Indietro
                  </Button>
                  {paymentMethod === 'card' && (
                    <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700 text-white py-6 text-lg">
                      Paga con Carta
                    </Button>
                  )}
                </div>
              </form>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-24">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">
                Riepilogo Ordine
              </h2>
              <div className="space-y-4 mb-6 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 truncate">
                        {item.name}
                      </h4>
                      <p className="text-sm text-gray-500">
                        Qty: {item.quantity}
                      </p>
                    </div>
                    <p className="font-semibold text-gray-900">
                      € {(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotale</span>
                  <span>€ {totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Spedizione</span>
                  <span className={shippingCost === 0 ? 'text-green-600' : ''}>
                    {shippingCost === 0 ? 'Gratuita' : `€ ${shippingCost.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between text-lg font-semibold pt-2 border-t">
                  <span>Totale</span>
                  <span className="text-blue-600">€ {totalWithShipping.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                  <Truck className="w-4 h-4" />
                  <span>Spedizione sicura</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Shield className="w-4 h-4" />
                  <span>Transazione sicura</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
