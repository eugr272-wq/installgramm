import Hero from '@/sections/Hero';
import Categories from '@/sections/Categories';
import Products from '@/sections/Products';
import About from '@/sections/About';

export default function HomePage() {
  return (
    <>
      <Hero />
      <Categories />
      <Products />
      <About />
    </>
  );
}
